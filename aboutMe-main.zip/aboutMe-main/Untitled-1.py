for i in range(10):
    for j in range(10):
        print (f"{i}{j}",end=" ")
    print("")