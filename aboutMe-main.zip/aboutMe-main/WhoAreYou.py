a=str(input("Name? "))
b=str(input("School? "))
c=str(input("Favorite Breakfast? "))
print ("hello ", a ,", who goes to school at ", b ,"! did you eat ", c ," today?")
while True:
    pass