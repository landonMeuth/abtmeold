import random
import time

while 1==1:
    time.sleep(0.02)
    name = []
    for a in range(1,21):
        x=bin(random.randint(0,1))
        name.append(x)
    print (name[0]+name[1]+name[2]+name[3]+name[4]+name[5]+name[6]+name[7]+name[8]+name[9]+name[10]+name[11]+name[12]+name[13]+name[14]+name[15]+name[16]+name[17]+name[18]+name[19])