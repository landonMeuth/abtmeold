a=0
b=1
c=1


while c<15:
    c=a+b
    print(a,"+",b,"=",c)
    b=b+1
    a=c
    
    