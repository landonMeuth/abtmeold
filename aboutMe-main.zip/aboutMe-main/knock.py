a=input("Knock, knock!")
if a==("Who's there?") or ("whos there"):
	a=input("Rufus.")
	if a==("Rufus who?") or ("rufus who"):
		print("Rufus the most important part of your house.")
while 1:
    pass